//
//  Appachhi.h
//  Appachhi
//
//  Created by Mohammed Irfan on 25/05/18.
//  Copyright © 2018 Appachhi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface appachhi : NSObject

// Method to Capture Launch Events
// Event name should be provided as per the exact scenario
// Ex: Start, ProcessingEnd, UIReady, Rendering complete etc.
+ (void) logEvent:(NSString *) msg;

// Asyncronous process to capture Device Performance
+ (void) capturePerformance;

// new comment added

@end
